/*USE master
GO
CREATE DATABASE CollegeDB
ON(
NAME = 'CollegeDB_Data_1',
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\CollegeDB_Data_1.mdf',
SIZE = 25 MB,
MAXSIZE = 100 MB,
FILEGROWTH = 5%
)
LOG ON(
NAME = 'CollegeDB_Log_1',
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\CollegeDB_Log_1.ldf',
SIZE = 2 MB,
MAXSIZE = 25 MB,
FILEGROWTH = 1%
)
GO

USE CollegeDB
GO
CREATE TABLE Teacher (
TeacherID INT NOT NULL PRIMARY KEY NONCLUSTERED,
TeacherName VARCHAR (1) NOT NULL
)
GO
CREATE TABLE Student (
StudentID INT NOT NULL PRIMARY KEY,
StudentName VARCHAR (2)
)
GO
CREATE TABLE Semester (
SemesterID INT NOT NULL PRIMARY KEY,
SemesterName VARCHAR (6) NOT NULL
)
GO
CREATE TABLE Subjects (
SubjectsID INT NOT NULL PRIMARY KEY,
SubjectName VARCHAR (20) NOT NULL
)
GO
CREATE TABLE Students (
StdID INT NOT NULL PRIMARY KEY,
StudentsName VARCHAR (11) NOT NULL
)
GO
CREATE TABLE Relations(
TeacherID INT REFERENCES Teacher (TeacherID),
StdID INT REFERENCES Students (StdID),
SemesterID INT REFERENCES Semester (SemesterID),
SubjectsID INT REFERENCES Subjects (SubjectsID),
PRIMARY KEY ( TeacherID, SubjectsID, SemesterID)
)
GO
CREATE CLUSTERED INDEX IX_Teacher_TeacherName
ON Teacher (TeacherName)
-- Justify
--EXEC sp_helpindex Teacher
GO

USE CollegeDB
GO
INSERT INTO Teacher (
TeacherID,
TeacherName
)
VALUES
(1, 'A'),
(2, 'B'),
(3, 'C')
GO
INSERT INTO Student (
StudentID,
StudentName
)
VALUES 
(1, 'AA'),
(2, 'BB'),
(3, 'CC'),
(4, 'DD'),
(5, 'EE'),
(6, 'FF'),
(7, 'GG'),
(8, 'HH'),
(9, 'II')
GO
INSERT INTO Semester (
SemesterID,
SemesterName
)
VALUES 
(1, 'Spring'),
(2, 'Summer'),
(3, 'Fall'),
(4, 'Winter')
GO
INSERT INTO Subjects (
SubjectsID,
SubjectName
)
VALUES
(1, 'C#'),
(2, 'Database'),
(3, 'Web Mining'),
(4, 'Software Engineering'),
(5, 'Net Working'),
(6, 'WDPF'),
(7, 'JAVA'),
(8, 'Web Design'),
(9, 'HTML')
GO
INSERT INTO Students (
StdID,
StudentsName
)
VALUES
(1, 'AA, BB, CC'),
(2, 'GG, HH, II'),
(3, 'DD, EE, FF'),
(4, 'BB, CC, II'),
(5, 'AA, HH, GG'),
(6, 'BB, CC, DD'),
(7, 'AA, HH, II'),
(8, 'EE, FF, GG'),
(9, 'DD, GG, EE'),
(10, 'FF, HH, II')
GO 
INSERT INTO Relations (
TeacherID,
StdID,
SemesterID,
SubjectsID
)
VALUES 
(1, 1, 1, 1),
(2, 2, 1, 2),
(3, 3, 1, 3),
(1, 3, 2, 1),
(2, 4, 2, 3),
(3, 5, 2, 4),
(1, 6, 3, 5),
(2, 7, 3, 2),
(3, 8, 3, 6),
(1, 1, 4, 7),
(2, 9, 4, 8),
(3, 10, 4, 9)
GO

-- Join Query

USE CollegeDB
GO
SELECT TeacherName AS Teacher, StudentsName AS Student, SemesterName AS Semester,
 SubjectName AS Subject FROM Relations JOIN Teacher ON
Relations.TeacherID = Teacher.TeacherID 
JOIN Students ON Relations.StdID = Students.StdID 
JOIN Semester ON Relations.SemesterID = Semester.SemesterID 
JOIN Subjects ON Relations.SubjectsID = Subjects.SubjectsID
GO

-- View

USE CollegeDB
GO
CREATE VIEW vw_collegedb
AS
SELECT TeacherName AS Teacher, StudentsName AS Student, SemesterName AS Semester, SubjectName AS Subject FROM Relations JOIN Teacher ON
Relations.TeacherID = Teacher.TeacherID JOIN Students ON
Relations.StdID = Students.StdID JOIN Semester ON
Relations.SemesterID = Semester.SemesterID JOIN Subjects ON 
Relations.SubjectsID = Subjects.SubjectsID
GO
-- Justify
-- SELECT * FROM vw_collegedb

USE CollegeDB
GO
CREATE PROC spInsertUpdateDelete
(
@id INT,
@name VARCHAR (2),
@stype VARCHAR (6)
)
AS
BEGIN
IF @stype = 'Insert'
BEGIN
INSERT Student (StudentID, StudentName)
VALUES (@id, @name)
END
IF @stype = 'Update'
BEGIN
UPDATE Student SET StudentName = @name
WHERE StudentID = @id
END
IF @stype = 'Delete'
BEGIN
DELETE FROM Student WHERE StudentID = @id
END
END

EXEC spInsertUpdateDelete 10, 'JJ ', 'Insert'

EXEC spInsertUpdateDelete 11, 'KK', 'Insert' 
EXEC spInsertUpdateDelete 11, 'LL', 'Update'
EXEC spInsertUpdateDelete 11, 'LL', 'Delete'
GO

USE CollegeDB
GO
SELECT StudentsName FROM Relations 
JOIN Students ON Students.StdID = Relations.StdID
WHERE SemesterID IN
(SELECT SemesterID FROM Semester WHERE SemesterName = 'Summer')
GO
USE CollegeDB
GO
CREATE PROC spInsertSyudent
@StudentID INT,
@StudentName VARCHAR (10),
@stype VARCHAR (6)
AS
BEGIN
IF @stype = 'Insert'
BEGIN TRY 
INSERT INTO Student
VALUES (@StudentID, @StudentName)
END TRY 
BEGIN CATCH
SELECT
ERROR_NUMBER() AS ErrorNumber,
ERROR_MESSAGE() AS ErrorMessage,
ERROR_STATE() AS ErrorSate,
ERROR_SEVERITY() AS ErrorSeverity 
END CATCH
END

EXEC spInsertSyudent 9, 'JJ', 'Insert'
GO

USE CollegeDB
GO
CREATE PROC spstudentcount
@StudentCount INT OUTPUT
AS
BEGIN
SELECT @StudentCount = COUNT (*) FROM Student 
END

-- Justify
DECLARE @count INT
EXEC spstudentcount @count OUTPUT 
PRINT @count
GO

--Scalar Function
USE CollegeDB
GO
CREATE FUNCTION fnGetStudentName (@StudentID INT)
RETURNS VARCHAR (10)
AS
BEGIN
DECLARE @name VARCHAR;
SELECT @name= StudentName FROM Student WHERE StudentID = @StudentID
RETURN @name
END
--Justify
SELECT dbo.fnGetStudentName (4) AS "Student Name"

-- Table Function
USE CollegeDB
GO
CREATE FUNCTION fnGetStudentList (@StudentID INT)
RETURNS TABLE
RETURN
SELECT * FROM Student WHERE StudentID > @StudentID
SELECT * FROM fnGetStudentList (5)
 
 --Trigger
CREATE TRIGGER trInsertStudent
ON Student
FOR INSERT 
AS
BEGIN
SELECT * FROM inserted
END
--Justify
INSERT INTO Student
VALUES (10, 'KK')

CREATE TRIGGER trStudentDelete
ON Student
FOR DELETE 
AS
BEGIN
PRINT 'You have no permission to delete data from this table'
ROLLBACK TRAN
END

-- Justify
DELETE FROM Student WHERE StudentID = 10
GO*/